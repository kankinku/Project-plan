# Tweet ID: 2011208619489181965

URL: https://x.com/JunDo1050/status/2011208619489181965

## Content

< Early signs of the great rotation >

지난 두 달간 이어져온 유사햇지 (pseudo-hedge)의 질주, 크립토시장의 횡보, VIX눌림과 컨탱고 현상...

워닝 시그널은 충분히 보았고,

이제 큰 전환이 시작되려는 조짐이 보이고 있음.

- 크립토  
- 주식시장  VIX 
- 유사햇지 횡보
- 국채시장 횡보
- USD (DXY index)  
